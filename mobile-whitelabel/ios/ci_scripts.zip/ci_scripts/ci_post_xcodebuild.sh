 #!/bin/sh

WORKFLOW_BUILD_ON_PR="Build on PR"
WORKFLOW_DEPLOY_TO_CUSTOMER="Deploy to Customer"

if [ "$CI_WORKFLOW" = "$WORKFLOW_BUILD_ON_PR" ]
    then 
    yarn run ios:distribute
elif [ "$CI_WORKFLOW" = "$WORKFLOW_DEPLOY_TO_CUSTOMER" ]
    then 
    yarn run ios:distribute:customer
fi