cd ../

WORKFLOW_BUILD_ON_PR="Build on PR"
WORKFLOW_DEPLOY_TO_CUSTOMER="Deploy to Customer"

if [ "$CI_WORKFLOW" = "$WORKFLOW_BUILD_ON_PR" ] || [ "$CI_WORKFLOW" = "$WORKFLOW_DEPLOY_TO_CUSTOMER" ]
    then 
    NEW_VERSION_NUMBER=`node -pe "require('../package.json').version"`-"$CI_BRANCH"-"$CI_PULL_REQUEST_NUMBER"
    agvtool new-marketing-version "${NEW_VERSION_NUMBER//\//-}"
fi
